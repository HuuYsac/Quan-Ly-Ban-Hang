import React, { useState } from 'react';
import { QrCode, Phone, Lock, Eye, EyeOff, ChevronRight, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';

export function ZaloLogin() {
  const [loginMethod, setLoginMethod] = useState<'qr' | 'phone'>('qr');
  const [showPassword, setShowPassword] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] bg-slate-50 p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200"
      >
        {/* Header */}
        <div className="bg-[#0068FF] p-8 text-center text-white">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
              <MessageCircle className="text-[#0068FF]" size={32} fill="currentColor" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight">Zalo</h1>
          </div>
          <p className="text-blue-100 font-medium">Đăng nhập tài khoản Zalo</p>
          <p className="text-blue-200 text-sm">để sử dụng các dịch vụ của Zalo</p>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-100">
          <button
            onClick={() => setLoginMethod('qr')}
            className={`flex-1 py-4 text-sm font-bold transition-colors relative ${
              loginMethod === 'qr' ? 'text-[#0068FF]' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            VỚI MÃ QR
            {loginMethod === 'qr' && (
              <motion.div 
                layoutId="activeTab"
                className="absolute bottom-0 left-0 right-0 h-1 bg-[#0068FF]"
              />
            )}
          </button>
          <button
            onClick={() => setLoginMethod('phone')}
            className={`flex-1 py-4 text-sm font-bold transition-colors relative ${
              loginMethod === 'phone' ? 'text-[#0068FF]' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            VỚI SỐ ĐIỆN THOẠI
            {loginMethod === 'phone' && (
              <motion.div 
                layoutId="activeTab"
                className="absolute bottom-0 left-0 right-0 h-1 bg-[#0068FF]"
              />
            )}
          </button>
        </div>

        {/* Content */}
        <div className="p-8">
          {loginMethod === 'qr' ? (
            <div className="flex flex-col items-center text-center space-y-6">
              <div className="relative p-4 bg-white border-2 border-slate-100 rounded-2xl shadow-inner group">
                <QrCode size={200} className="text-slate-800" />
                <div className="absolute inset-0 bg-white/80 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl">
                  <button className="p-3 bg-[#0068FF] text-white rounded-full shadow-lg hover:bg-blue-700 transition-colors">
                    <RefreshCw size={24} />
                  </button>
                  <p className="text-xs font-bold text-[#0068FF] mt-2">LÀM MỚI MÃ</p>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-slate-600">
                  Quét mã QR bằng ứng dụng Zalo để đăng nhập
                </p>
                <p className="text-xs text-slate-400">
                  Mã QR sẽ hết hạn sau <span className="text-red-500 font-bold">01:59</span>
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="space-y-4">
                {/* Phone Input */}
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                    <Phone size={18} />
                  </div>
                  <input
                    type="tel"
                    placeholder="Số điện thoại"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0068FF]/20 focus:border-[#0068FF] outline-none transition-all"
                  />
                </div>

                {/* Password Input */}
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
                    <Lock size={18} />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Mật khẩu"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-11 pr-12 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0068FF]/20 focus:border-[#0068FF] outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer group">
                  <div className="relative flex items-center justify-center">
                    <input type="checkbox" className="peer sr-only" />
                    <div className="w-5 h-5 border-2 border-slate-200 rounded bg-white peer-checked:bg-[#0068FF] peer-checked:border-[#0068FF] transition-all" />
                    <svg className="absolute w-3 h-3 text-white opacity-0 peer-checked:opacity-100 transition-opacity" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                      <path d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-sm text-slate-500 group-hover:text-slate-700 transition-colors">Ghi nhớ đăng nhập</span>
                </label>
                <button className="text-sm font-medium text-slate-500 hover:text-[#0068FF] transition-colors">
                  Quên mật khẩu?
                </button>
              </div>

              <button className="w-full py-3.5 bg-[#0068FF] text-white rounded-xl font-bold shadow-lg shadow-blue-500/30 hover:bg-blue-700 transition-all active:scale-[0.98]">
                Đăng nhập với mật khẩu
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400">
            Bạn chưa có tài khoản?{' '}
            <button className="text-[#0068FF] font-bold hover:underline">Đăng ký ngay!</button>
          </p>
        </div>
      </motion.div>

      {/* External Link */}
      <div className="mt-8 flex items-center gap-4">
        <a 
          href="https://chat.zalo.me" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium text-slate-600 hover:bg-slate-50 hover:border-slate-300 transition-all"
        >
          Mở Zalo Web chính thức
          <ChevronRight size={16} />
        </a>
      </div>
    </div>
  );
}

function RefreshCw({ size }: { size: number }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M3 21v-5h5" />
    </svg>
  );
}
